---
name: aria-orch-delegation-planner
description: Apply mandatory delegation policy and generate the correct routing plan across connected agents.
---

# ARIA Orchestrator Delegation Planner

## Purpose
Build a routing plan that follows orchestrator delegation order.

## When To Use
- After intent classification and before agent call.

## Input Contract
- intent: required value
- user_message: required string
- policy_snapshot: required object

## Output Contract
- plan_steps: ordered list
- target_agents: list
- pass_through_required: boolean
- execute_delegation_now: true

## Rules
1. For every in-scope request, plan Knowledge Agent as the first step.
2. If incident/ticket action or status is requested, plan Incident Agent as a later step after Knowledge Agent.
3. Keep plan minimal and deterministic.
4. Preserve pass-through requirement for delegated responses.
5. Planner output is not a final user response.
6. Always set execute_delegation_now=true when at least one connected agent target exists.
7. Only out_of_scope requests may produce a plan with no connected agent targets.
